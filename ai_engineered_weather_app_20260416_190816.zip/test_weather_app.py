import unittest
from weather_app import WeatherSystem

class TestWeatherSystem(unittest.TestCase):
    def setUp(self):
        self.weather_system = WeatherSystem()

    def test_get_forecast(self):
        city_name = "TestCity"
        forecast = self.weather_system.get_forecast(city_name)
        self.assertEqual(forecast['city'], city_name)
        self.assertEqual(len(forecast['forecast']), 5)
        for day in forecast['forecast']:
            self.assertIn('date', day)
            self.assertIn('temperature', day)
            self.assertIn('humidity', day)

    def test_parse_forecast_data(self):
        raw_data = {
            'city': 'SampleCity',
            'list': [
                {'date': '2023-10-01', 'temperature': 20, 'humidity': 80},
                {'date': '2023-10-02', 'temperature': 21, 'humidity': 75}
            ]
        }
        result = self.weather_system.parse_forecast_data(raw_data)
        self.assertEqual(result['city'], raw_data['city'])
        self.assertEqual(len(result['forecast']), 2)
        self.assertEqual(result['forecast'][0]['date'], '2023-10-01')
        self.assertEqual(result['forecast'][0]['temperature'], 20)
        self.assertEqual(result['forecast'][0]['humidity'], 80)

    def test_mock_api_request(self):
        city_name = "AnotherCity"
        raw_data = self.weather_system.mock_api_request(city_name)
        self.assertEqual(raw_data['city'], city_name)
        self.assertEqual(len(raw_data['list']), 5)
        expected_first_date = '2023-10-01'
        self.assertEqual(raw_data['list'][0]['date'], expected_first_date)

if __name__ == '__main__':
    unittest.main()
