import gradio as gr
from weather_app import WeatherSystem

# Create an instance of the WeatherSystem class
weather_system = WeatherSystem()

# Define a function to interact with the WeatherSystem and get forecast

def get_weather_forecast(city_name):
    forecast = weather_system.get_forecast(city_name)
    formatted_forecast = f"Weather Forecast for {forecast['city']}\n"
    for day in forecast['forecast']:
        formatted_forecast += f"Date: {day['date']}, Temperature: {day['temperature']}°C, Humidity: {day['humidity']}%\n"
    return formatted_forecast

# Gradio Interface
description = "Enter a city name to get a 5-day weather forecast."

gui = gr.Interface(
    fn=get_weather_forecast,
    inputs=gr.inputs.Textbox(label="City Name"),
    outputs=gr.outputs.Textbox(label="Weather Forecast"),
    title="5-Day Weather Forecast",
    description=description,
)

gui.launch()
