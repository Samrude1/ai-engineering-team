class WeatherSystem:
    def __init__(self):
        """
        Initialize the WeatherSystem class with necessary configurations.
        """
        # Initialize configurations such as API keys, base URL, etc. (mock in this case)
        self.base_url = "https://mockapi.weather"

    def get_forecast(self, city_name: str) -> dict:
        """
        Retrieve the 5-day weather forecast for a specified city.

        Parameters:
            city_name (str): Name of the city for which to retrieve the weather forecast.

        Returns:
            dict: A dictionary containing the weather forecast data for 5 days.
        """
        raw_data = self.mock_api_request(city_name)
        forecast_data = self.parse_forecast_data(raw_data)
        return forecast_data

    def parse_forecast_data(self, raw_data: dict) -> dict:
        """
        Parse raw data received from the API into a structured format.

        Parameters:
            raw_data (dict): Raw data received from the mock API.

        Returns:
            dict: A dictionary containing processed forecast information.
        """
        structured_data = {
            'city': raw_data.get('city'),
            'forecast': [
                {
                    'date': forecast['date'],
                    'temperature': forecast['temperature'],
                    'humidity': forecast['humidity']
                }
                for forecast in raw_data.get('list', [])
            ]
        }
        return structured_data

    def mock_api_request(self, city_name: str) -> dict:
        """
        Simulate a request to a mock Weather API to get forecast data.

        Parameters:
            city_name (str): Name of the city for the request.

        Returns:
            dict: Simulated response from the mock API.
        """
        return {
            'city': city_name,
            'list': [
                {'date': '2023-10-01', 'temperature': 20, 'humidity': 80},
                {'date': '2023-10-02', 'temperature': 21, 'humidity': 75},
                {'date': '2023-10-03', 'temperature': 19, 'humidity': 85},
                {'date': '2023-10-04', 'temperature': 22, 'humidity': 78},
                {'date': '2023-10-05', 'temperature': 23, 'humidity': 76}
            ]
        }
